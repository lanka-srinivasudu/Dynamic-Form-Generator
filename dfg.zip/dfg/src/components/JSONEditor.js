import React, { useState } from 'react';

const JSONEditor = ({ onChange }) => {
  const [jsonText, setJsonText] = useState('');

  const handleChange = (e) => {
    const newValue = e.target.value;
    setJsonText(newValue);

    try {
      const parsedJSON = JSON.parse(newValue);
      onChange(parsedJSON);
    } catch (error) {
      console.error("Invalid JSON", error);
    }
  };

  return (
    <div className="w-full p-4 border border-gray-300 rounded-md dark:border-gray-600">
      <label className="block text-lg font-medium text-gray-700 dark:text-gray-200 mb-2">Enter JSON Data</label>
      <textarea
        value={jsonText}
        onChange={handleChange}
        className="w-full h-40 p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:bg-gray-800 dark:border-gray-600 dark:text-gray-200"
        placeholder="Enter valid JSON schema..."
      />
    </div>
  );
};

export default JSONEditor;
