import React from 'react';
import { useForm } from 'react-hook-form';

const DynamicForm = ({ formSchema }) => {
  const { register, handleSubmit, formState: { errors } } = useForm();

  const onSubmit = (data) => {
    console.log(data);
    alert('Form submitted successfully');
  };

  return (
    <div className="w-full p-6 border border-gray-300 rounded-md dark:border-gray-700">
      <form onSubmit={handleSubmit(onSubmit)} className="space-y-6">
        <h2 className="text-2xl font-semibold text-gray-700 dark:text-gray-200 mb-4">
          {formSchema?.formTitle || 'Form'}
        </h2>

        {formSchema?.fields?.map((field) => (
          <div key={field.id} className="flex flex-col">
            <label htmlFor={field.id} className="text-gray-600 dark:text-gray-300 font-medium mb-2">
              {field.label}
            </label>
            <input
              id={field.id}
              type={field.type}
              placeholder={field.placeholder}
              {...register(field.id, { required: field.required })}
              className="mt-1 p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-indigo-500 dark:bg-gray-800 dark:border-gray-600 dark:text-gray-200"
            />
            {errors[field.id] && (
              <p className="text-red-500 text-sm mt-1">{errors[field.id].message || 'This field is required'}</p>
            )}
          </div>
        ))}

        <button
          type="submit"
          className="w-full py-2 px-4 bg-gradient-to-r from-green-400 via-blue-500 to-purple-600 text-white font-bold rounded-md hover:opacity-90 transition-opacity duration-300"
        >
          Submit
        </button>
      </form>
    </div>
  );
};

export default DynamicForm;
