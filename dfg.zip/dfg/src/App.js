import React, { useState, useEffect } from 'react';
import JSONEditor from './components/JSONEditor';
import DynamicForm from './components/DynamicForm';

const App = () => {
  const [formSchema, setFormSchema] = useState(null);
  const [darkMode, setDarkMode] = useState(false);

  useEffect(() => {
    if (darkMode) {
      document.documentElement.classList.add('dark');
    } else {
      document.documentElement.classList.remove('dark');
    }
  }, [darkMode]);

  return (
    <div className="min-h-screen bg-gray-50 dark:bg-gray-900 p-8 transition duration-500 ease-in-out">
      <div className="flex justify-between mb-4">
        <h1 className="text-2xl font-bold text-gray-700 dark:text-gray-200">Dynamic Form Generator</h1>
        <button
          onClick={() => setDarkMode(!darkMode)}
          className="py-2 px-4 bg-gradient-to-r from-purple-400 via-pink-500 to-red-500 text-white rounded-md hover:opacity-90 focus:outline-none"
        >
          Toggle {darkMode ? 'Light' : 'Dark'} Mode
        </button>
      </div>

      <div className="flex flex-col md:flex-row space-y-8 md:space-y-0 md:space-x-8">
        <div className="w-full md:w-1/2 bg-white dark:bg-gray-800 p-6 shadow-lg rounded-md border border-gray-300 dark:border-gray-700">
          <JSONEditor onChange={setFormSchema} />
        </div>

        <div className="w-full md:w-1/2 bg-white dark:bg-gray-800 p-6 shadow-lg rounded-md border border-gray-300 dark:border-gray-700">
          {formSchema ? (
            <DynamicForm formSchema={formSchema} />
          ) : (
            <p className="text-gray-500 dark:text-gray-400">Enter valid JSON data to generate a form</p>
          )}
        </div>
      </div>
    </div>
  );
};

export default App;
